package com.victoria.driver.data.pojo

class ErrorData(val t: Throwable)