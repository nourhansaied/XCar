package com.victoria.driver.ui.interfaces;

/**
 * Created on 19/11/18.
 */
public interface CallbackHistory {
    public void onOpenDetailsScreen(int adapterPosition);

    public void onOpenCancelRide();
}
