package com.victoria.driver.error;

/**
 * Created by h-link9 on 10/09/2015.
 */

public class G {

    public static String FILES_PATH = null;
    public static String APP_VERSION = "unknown";
    public static String APP_PACKAGE = "unknown";
    public static String PHONE_MODEL = "unknown";
    public static String ANDROID_VERSION = "unknown";
    public static String URL = "http://trace.nullwire.com/collect/";
    public static String TraceVersion = "0.3.0";
    public static String TraceAVersion = "Created By: Himesh Goswami @2015";

    public G() {
    }
}

