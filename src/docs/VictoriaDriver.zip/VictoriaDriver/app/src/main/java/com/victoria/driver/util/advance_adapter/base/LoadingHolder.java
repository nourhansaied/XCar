package com.victoria.driver.util.advance_adapter.base;

import android.view.View;

public class LoadingHolder extends BaseHolder {
    public LoadingHolder(View itemView) {
        super(itemView);
    }
}