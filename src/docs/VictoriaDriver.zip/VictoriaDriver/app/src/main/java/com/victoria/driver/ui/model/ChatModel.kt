package com.victoria.driver.ui.model

class ChatModel(var textMsg: String,var time:String, var isUser: Boolean) {
}
