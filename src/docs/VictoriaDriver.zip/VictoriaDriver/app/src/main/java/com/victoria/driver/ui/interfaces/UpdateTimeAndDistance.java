package com.victoria.driver.ui.interfaces;

public interface UpdateTimeAndDistance {
    void onComplete(String time, String km);
}