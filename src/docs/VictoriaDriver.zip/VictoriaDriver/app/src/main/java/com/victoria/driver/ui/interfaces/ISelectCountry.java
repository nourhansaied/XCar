package com.victoria.driver.ui.interfaces;

import com.victoria.driver.ui.model.CountryData;

public interface ISelectCountry {
    void selectCountry(String s, String s1, CountryData id);

}
