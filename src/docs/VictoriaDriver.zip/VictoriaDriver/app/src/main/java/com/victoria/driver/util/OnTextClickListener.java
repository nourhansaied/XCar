package com.victoria.driver.util;

import android.view.View;

public interface OnTextClickListener {

    void onClick(View view, String text);

}