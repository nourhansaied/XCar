package com.victoria.driver.exception


class AuthenticationException : RuntimeException()
