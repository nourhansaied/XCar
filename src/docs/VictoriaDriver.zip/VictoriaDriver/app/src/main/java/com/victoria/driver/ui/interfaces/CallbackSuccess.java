package com.victoria.driver.ui.interfaces;

/**
 * Created on 1/6/18.
 */
public interface CallbackSuccess {

    public void onSuccess();
}
