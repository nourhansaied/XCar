package com.victoria.driver.ui.interfaces;


/**
 * Created by h-link9 on 31/07/2017.
 */

public interface ItemClickListener {
    public void onItemEventFired(String t, int pos);
}
