package com.victoria.customer.ui.interfaces;


/**
 * Created by on 31/07/2017.
 */

public interface ItemClickListener {
     void onItemEventFired(String t, int pos);
}
