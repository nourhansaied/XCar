package com.victoria.customer.data.pojo;
class ErrorData(val t: Throwable)