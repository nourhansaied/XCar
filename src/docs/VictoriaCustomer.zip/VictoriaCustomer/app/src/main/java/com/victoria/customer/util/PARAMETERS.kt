package com.victoria.customer.util

/**
 * Created on 28/5/18.
 */
interface PARAMETERS {
    companion object {



        const val PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place"
        const val TYPE_AUTOCOMPLETE = "/autocomplete"
        const val OUT_JSON = "/json"
        var PARAM_SCREEN="Screen"

        const val FORMATE_1 = "yyyy-MM-dd hh:mm:ss"
        const val FORMATE_2 = "EEE, dd-MMM h:mm a"

        const val KEY_IS_LOGIN = "is_login"


    }


}
