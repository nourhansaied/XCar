package com.victoria.customer.model

/**
 * Created on 10/10/18.
 */
class CurrentRide {

    var latitude:Double = 0.0
    var longitude:Double = 0.0
}