package com.victoria.customer.ui.manager;
/**
 * Created by hlink21 on 27/5/16.
 */
interface Passable<in T> {

    fun passData(t: T)

}
