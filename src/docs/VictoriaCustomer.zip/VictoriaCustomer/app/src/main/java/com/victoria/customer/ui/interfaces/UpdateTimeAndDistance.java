package com.victoria.customer.ui.interfaces;

public interface UpdateTimeAndDistance {
    void onComplete(String time, String km);
}