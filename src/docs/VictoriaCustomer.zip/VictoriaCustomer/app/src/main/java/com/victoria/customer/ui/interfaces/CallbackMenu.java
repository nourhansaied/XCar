package com.victoria.customer.ui.interfaces;

/**
 * Created on 1/6/18.
 */
public interface CallbackMenu {

     void onCallBack(int id);

}
