package com.victoria.customer.ui.interfaces;


import com.victoria.customer.model.CountryData;

public interface ISelectCountry {
    void selectCountry(String s, String s1, CountryData id);

}
