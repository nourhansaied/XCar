package com.victoria.customer.exception;


class AuthenticationException : RuntimeException()
