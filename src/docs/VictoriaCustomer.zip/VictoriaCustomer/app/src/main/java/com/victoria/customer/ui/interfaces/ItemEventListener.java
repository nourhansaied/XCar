package com.victoria.customer.ui.interfaces;

import com.victoria.customer.model.VictoriaVehicleData;

/**
 * Created by h-link9 on 31/07/2017.
 */

public interface ItemEventListener {
     void onItemEventFired(VictoriaVehicleData t, int pos);
}
