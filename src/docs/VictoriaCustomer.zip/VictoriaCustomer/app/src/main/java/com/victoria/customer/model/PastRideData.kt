package com.victoria.customer.model

/**
 * Created on 8/10/18.
 */
class PastRideData (var dateTime:String)