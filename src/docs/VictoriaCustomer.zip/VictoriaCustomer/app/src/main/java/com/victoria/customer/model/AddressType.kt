package com.victoria.customer.model

import com.victoria.customer.core.Common

/**
 * Created on 27/3/19.
 */
class AddressType(var address:String,var addressType:Common.AddressType)