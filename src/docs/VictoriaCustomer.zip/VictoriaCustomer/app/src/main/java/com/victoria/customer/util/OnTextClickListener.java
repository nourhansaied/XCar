package com.victoria.customer.util;

import android.view.View;

public interface OnTextClickListener {

  void onClick(View view, String text);

}